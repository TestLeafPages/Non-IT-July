package baseclass;

public class Learnrandom {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int random = (int)(Math.random() *(9999999));
		System.out.println(random);
	}

}
