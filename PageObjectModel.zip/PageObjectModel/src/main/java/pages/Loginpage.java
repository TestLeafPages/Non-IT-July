package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

import baseclass.ProjectSpecificMethod;

public class Loginpage extends ProjectSpecificMethod{
	
	public Loginpage(RemoteWebDriver driver) {	
		this.driver=driver;		
	}	
	
	public Loginpage enterUsername(String uname) {
		driver.findElement(By.id("username")).sendKeys(uname);
		//Loginpage lp=new Loginpage();
		//return new Loginpage();
		return this;
	}
	
	
    public Loginpage enterPassword(String pwd) {
    	driver.findElement(By.id("password")).sendKeys(pwd);
		return this;
	}
	
    public WelcomePage clickLogin() {    	
    	driver.findElement(By.className("decorativeSubmit")).click();
    	return new WelcomePage(driver);
    	
	}
	
	
	
}
